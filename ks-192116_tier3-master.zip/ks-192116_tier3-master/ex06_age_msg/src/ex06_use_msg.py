#! /usr/bin/env python

import rospy                                          
from ex06_use_msg.msg import Age

                                    # Define a function called 'callback' that receives a parameter 
rospy.init_node('use_msg')

Age=Age()

Age.Years=26                                                   # named 'msg'
Age.Months=1
Age.Days=25
    print Age.Years
    print Age.Months
    print Age.Days                         # Print the value 'data' inside the 'msg' parameter
                  

rospy.spin()        
		
