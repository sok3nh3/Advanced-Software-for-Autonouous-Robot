#! /usr/bin/env python

import rospy
import actionlib
from geometry_msgs.msg import Twist
from ex12_turtle_as.msg import MoveAction, MoveGoal, MoveFeedback, MoveResult


#success= true
mov_fwd=Twist()
mov_back=Twist()
stop =Twist()
stop.linear.x=0

def callback(goal):
    rate = rospy.Rate(2)
    success = False

    feedback=MoveFeedback()
    result=MoveResult()
    
    if goal.direction == "Forward":
       mov_fwd.linear.x=0.4
       pub.publish(mov_fwd)
       feedback.current_state="Moving forward !"
       action_server.publish_feedback(feedback)
       #result.final_state="Finished moving!"
       action_server.set_succeeded(result)
       rospy.sleep(goal.duration)
       success = True
       pub.publish(stop)
    
    elif goal.direction == "Backward":
         mov_back.linear.x=-0.4
	 pub.publish(mov_back)
       	 feedback.current_state="Moving Backward!"
       	 action_server.publish_feedback(feedback)
         action_server.set_succeeded(result)
	 rospy.sleep(goal.duration)
         success = True
       	 pub.publish(stop)
    else:
	rospy.loginfo('Please specify FORWARD or BACKWARD!')
	pub.publish(stop)

    if success:
        result.final_state = "Finished Moving!!"
        rospy.loginfo(result)
        action_server.set_succeeded(result)
	
rospy.init_node('ex12_turtle_as')
pub = rospy.Publisher("/cmd_vel", Twist, queue_size= 10)
action_server = actionlib.SimpleActionServer("ex12_turtle_as",MoveAction, callback, auto_start = False)
action_server_name = "TurtleBot Action Message Service"
action_server.start()
rospy.spin()
    
