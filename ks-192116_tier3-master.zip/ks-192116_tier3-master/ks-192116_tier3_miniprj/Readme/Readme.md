Moving Turtle Boot for different goals:
In this Project we are moving the turtle boot from Gazebo simulation to twenty different goals which will be published by another goal_publisher package(a separate folder in the repository) using python libraries and rostopics.

Beginning :

In the beginning we have sent the

General description
Write a short overview what the goal of the project was.
What topics and/or services are used/created. What do they do?
(Short description)
What components do what?

Algorithm description
Abstract description of the implemented algorithm.

Implementation
Describe how the algorithm abstractly described above was implemented.

Problems and solutions
If you have mention worthy problems with a elegant solution you should mention
that in the readme.
