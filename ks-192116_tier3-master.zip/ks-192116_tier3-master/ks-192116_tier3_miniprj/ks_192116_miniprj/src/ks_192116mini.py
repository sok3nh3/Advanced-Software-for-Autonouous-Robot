#! /usr/bin/env python

# import ros stuff
import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist, Point
from gazebo_msgs.msg import ModelStates
from tf import transformations
from tf.transformations import euler_from_quaternion
from goal_publisher.msg import PointArray
from std_srvs.srv import *
import math
import pdb

x=0
y=0
theta=0
desired_theta=0
error_position=0
dest_position=0
dist_tolerance =0.1
angle_diff=0
area=""
point_x=[0.0]*20
point_y=[0.0]*20
point_z=[0.0]*20
i=0

def goal_points(msg):
	global point_x
	global point_y
	global point_z
	point_x=[msg.goals[i].x for i in range(len(msg.goals))]
        point_y=[msg.goals[i].y for i in range(len(msg.goals))]
        point_z=[msg.goals[i].z for i in range(len(msg.goals))]
	#print(point_x)
def clbk_laser(msg):
    global area
    area = {
        'front' : min(min(msg.ranges[0:35]),min(msg.ranges[325:359]),3.5),
		'fleft' : min(min(msg.ranges[36:107]),3.5),
		'left' : min(min(msg.ranges[108:179]),3.5),
		'right' : min(min(msg.ranges[180:251]),3.5),
		'fright' : min(min(msg.ranges[252:324]),3.5)
    }

def model(Pos):
    global x
    global y
    global theta
    x = Pos.pose[1].position.x
    y = Pos.pose[1].position.y
    quaternion_orient = Pos.pose[1].orientation
    [roll , pitch , theta]= euler_from_quaternion([quaternion_orient.x, quaternion_orient.y, quaternion_orient.z, quaternion_orient.w])
    #print("x : {},y : {},theta:{}".format(x,y,theta))

def main():
	global dest_position,error_position,desired_theta,i,speed,pub,point_x
	rospy.init_node("mini")
	sub = rospy.Subscriber("/gazebo/model_states",ModelStates, model)
	sub_laser = rospy.Subscriber('/scan', LaserScan, clbk_laser) 
	pub = rospy.Publisher("/cmd_vel",Twist,queue_size=1)
	sub_goal = rospy.Subscriber("/goals", PointArray, goal_points)
	print(point_x)    	
	dest_position=Point()
	speed=Twist()
	dest_position.x=point_x[4]
	dest_position.y=point_y[4]
	rate=rospy.Rate(4)
	while not rospy.is_shutdown():   
		inc_x=dest_position.x-x
		inc_y=dest_position.y-y
		rate=rospy.Rate(4)
		desired_theta=math.atan2(inc_y,inc_x)
		error_position = math.sqrt(pow(dest_position.y - y, 2) + pow(dest_position.x - x, 2))
		while error_position>0.1:
			if abs(desired_theta-theta)>0.1:
			   speed.angular.z=0.3*abs(desired_theta-theta)
			   speed.linear.x=0
			   pub.publish(speed)
			elif abs(error_position)>0.1:
			     speed.linear.x=0.3
			     speed.angular.z=0
			     pub.publish(speed)
			else:
			     speed.linear.x=0
			     speed.angular.z=0
			     pub.publish(speed)	
				
			rate.sleep()
if __name__ == "__main__":
     main()

