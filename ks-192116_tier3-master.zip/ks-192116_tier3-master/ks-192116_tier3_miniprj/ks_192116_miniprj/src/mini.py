#!/usr/bin/env python
import rospy
import math
from std_msgs.msg import String
from std_msgs.msg import Int32
from geometry_msgs.msg import Twist          # Import the Twist message from the geometry_msgs
from sensor_msgs.msg import LaserScan       # Import the LaserScan message from the sensor
from gazebo_msgs.msg import ModelStates  #import ModelState message from gazebo_msgs
from geometry_msgs.msg import Pose,Point         # Import the Pose message from the geometry_msgs
from tf.transformations import euler_from_quaternion
from goal_publisher.msg import PointArray
from math import pow, atan2, sqrt
import pdb

print_x=[0.0]*20
print_y=[0.0]*20
print_z=[0.0]*20
i=0
speed=Twist()
x=0
y=0
j=0
theta=0
regions={}
error_theta=0
error_position=0
dest_position=Point()
dest_position.x=0
dest_position.y=0
dest_position.z=0

def model(msg):
    global x
    global y
    global theta
    x=msg.pose[1].position.x
    y=msg.pose[1].position.y
    rot_q=msg.pose[1].orientation
    (roll,pitch,theta)=euler_from_quaternion([rot_q.x,rot_q.y,rot_q.z,rot_q.w])


def callback(msg):
    global print_x,print_y,i,print_z
    print_x=[msg.goals[i].x for i in range(len(msg.goals))]
    print_y=[msg.goals[i].y for i in range(len(msg.goals))]
    print_z=[msg.goals[i].z for i in range(len(msg.goals))]
    #print(print_x)


def laser(msg):
    global regions
    regions = {
        'front' : min(min(msg.ranges[0:35]),min(msg.ranges[325:359]),1),
	'fleft' : min(min(msg.ranges[36:107]),1),
	'left' : min(min(msg.ranges[108:179]),1),
	'right' : min(min(msg.ranges[180:251]),1),
	'fright' : min(min(msg.ranges[252:324]),1)
    }



def set_angle(dest_position):
    global error_theta   
    error_theta=math.atan2(dest_position.y - y,dest_position.x - x)
    angle=error_theta-theta
    if(math.fabs(angle) > math.pi):
        angle = angle - (2 * math.pi * angle) / (math.fabs(angle))
    speed=Twist()
    if abs(angle) > 0.3:
          speed.angular.z=0.4 if angle>0 else -0.4
          pub.publish(speed)
    if abs(angle)<0.1:
       set_point(dest_position)   
    print(angle)


def set_point(dest_position):
    global print_x,print_y,pub,error_theta,error_position
    error_theta=math.atan2(dest_position.y - y,dest_position.x - x)
    error_position = math.sqrt(pow(dest_position.y - y, 2) + pow(dest_position.x - x, 2))
    print(error_theta)
    print(dest_position)
    speed=Twist()

    if  abs(error_position) > 0.3:
          speed.linear.x=0.4
          pub.publish(speed)
    if  abs(error_position) <0.1:		
        speed.linear.x=0
        pub.publish(speed)
    print("goal:{} reached".format(i))    
    print(error_position)

def main():
       global print_x,pub,error_position,i,error_theta
       rospy.init_node('mini')   
       rate = rospy.Rate(10)    
       pub = rospy.Publisher('cmd_vel',Twist, queue_size=10)
       goals_sub = rospy.Subscriber('/goals',PointArray,callback)
       pose_sub = rospy.Subscriber('/gazebo/model_states',ModelStates,model)
       laser_sub = rospy.Subscriber('scan', LaserScan,laser)
       rospy.sleep(2)
       i=input("which goal ")
       j=i
       dest_position=Point()
       dest_position.x=print_x[i]
       dest_position.y=print_y[i]
       error_theta=math.atan2(dest_position.y - y,dest_position.x - x)
       error_position = math.sqrt(pow(dest_position.y - y, 2) + pow(dest_position.x - x, 2))
       
       while not rospy.is_shutdown():
	     if error_theta >0.1:
	     	set_angle(dest_position)
             elif error_position>0.1:
                  set_point(dest_position)
	     elif error_position<0.1:
		 
		 speed=Twist()
                 speed.linear.x=0
		 speed.angular.z=0
	         pub.publish(speed)
		 rospy.sleep(2)
	     else:
		 break
    	     
            
            
if __name__ == '__main__':
  	main()
        rate.sleep()
