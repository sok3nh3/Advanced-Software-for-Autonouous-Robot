#! /usr/bin/env python

import rospy
import math
import os
from std_srvs.srv import Empty, EmptyResponse
from geometry_msgs.msg import Twist, Point
from tf.transformations import euler_from_quaternion
from nav_msgs.msg import Odometry
from goal_publisher.msg import PointArray
from ex10_my_srv_msg.srv import MyServiceMsg,MyServiceMsgResponse
from math import atan2

x=0
y=0
theta=0

def odome(Pos):
    global x
    global y
    global theta
    x = Pos.pose.pose.position.x
    y = Pos.pose.pose.position.y
    quaternion_orient = Pos.pose.pose.orientation
    [roll , pitch , theta]= euler_from_quaternion([quaternion_orient.x, quaternion_orient.y, quaternion_orient.z, quaternion_orient.w])
    print("x : {},y : {},theta:{}".format(x,y,theta))

def callback(request):	
	sub = rospy.Subscriber("/odom",Odometry, odome) 
	pub = rospy.Publisher("/cmd_vel",Twist,queue_size=1)

	rad = request.radius
    	rep = request.repetitions
	speed=Twist()
	angle=90 * (math.pi/180)
        
        for i in range(rep):
	      i+=1
	# first corner 
	      while abs(x-rad) > 0.1:      #linear motion
		    speed.linear.x = 0.3
		    speed.linear.y = 0
		    pub.publish(speed)
		    print("x : {},y :{}, theta :{}".format(x,y,theta))
	      speed.linear.x=0
	      speed.linear.y=0
	      pub.publish(speed)
	      while abs(theta-angle) > 0.01:
	      	    speed.angular.z = 0.2 * abs(theta - angle)
	       	    pub.publish(speed)
	      speed.angular.z = 0
	      speed.linear.x = 0
	      pub.publish(speed)
	      print("x : {}, y : {}, theta : {}".format(x,y,theta))
	        #changing the target angle
	      angle = 180 * (math.pi/180)

		# second corner for i in range(rep):
	      while abs(rad-y) > 0.1:      #linear motion
       	       	    speed.linear.x = 0.3	
       		    speed.linear.y = 0
       		    pub.publish(speed)
       		    print("x : {},y :{}, theta :{}".format(x,y,theta))
	      speed.linear.x=0
	      speed.linear.y=0
	      pub.publish(speed)
	
	      while abs(theta-angle) > 0.01:
	       	     speed.angular.z = 0.2 * abs(theta - angle)
	       	     pub.publish(speed)
	      speed.angular.z = 0
	      speed.linear.x = 0
	      pub.publish(speed)
	      print("x : {}, y : {}, theta : {}".format(x,y,theta))
	      #changing the target angle
	      angle = -math.pi/2
	
	# third corner 
	      while abs(x) > 0.1:      #linear motion
		    speed.linear.x = 0.3
		    speed.linear.y = 0
	       	    pub.publish(speed)
	       	    print("x : {},y :{}, theta :{}".format(x,y,theta))
	      speed.linear.x=0
	      speed.linear.y=0
	      pub.publish(speed)
	
	      while abs(angle-theta) > 0.01:
	            speed.angular.z = 0.2 * abs(theta - angle)
	            pub.publish(speed)
	      speed.angular.z = 0
	      speed.linear.x = 0
	      pub.publish(speed)
	      print("x : {}, y : {}, theta : {}".format(x,y,theta))
	      #changing the target angle
	      angle = 0
	
		# fourth corner 
	      while y> 0.1:      #linear motion
	            speed.linear.x = 0.3
	            speed.linear.y = 0
	            pub.publish(speed)
	            print("x : {},y :{}, theta :{}".format(x,y,theta))
	      speed.linear.x=0
	      speed.linear.y=0
	      pub.publish(speed)
	
	      while abs(theta-angle) > 0.001:
       		    speed.angular.z = 0.2 * abs(theta - angle)
       		    pub.publish(speed)
	      speed.angular.z = 0
              speed.linear.x = 0
	      pub.publish(speed)

	      os.system("clear")
	      print("x : {}, y : {}, theta : {}".format(x,y,theta))

	if i == radius:
        	my_response = multi_square_serviceResponse()
        	my_response.success = True
        return my_response
rospy.init_node('Square')
my_service = rospy.Service('/MyServiceMsg',MyServiceMsg,callback)
rospy.spin()

                       

