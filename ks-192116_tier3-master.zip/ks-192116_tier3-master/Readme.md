# Welcome to Tier 3!

Let's get serious! In this tier we will start with learing ros. This is a large tier and it will be updated as we move along. So check your issues frequently for updates ;)

![](https://fbe-gitlab.hs-weingarten.de/mat-iki/amr-mat/raw/master/.img/tier3.png)


