#! /usr/bin/env python

import rospy                                          
from geometry_msgs.msg import Twist

def callback(var):                                    # Define a function called 'callback' that receives a parameter 
                                                      # named 'msg'
  
    print var.linear.x
                                  # Print the value 'data' inside the 'msg' parameter

rospy.init_node('vel_subscriber')                  

sub = rospy.Subscriber('/cmd_vel', Twist,callback)   # Create a Subscriber object that will listen to the /counter
                                                      # topic and will cal the 'callback' function each time it reads
                                                      # something from the topic
rospy.spin()        
		
