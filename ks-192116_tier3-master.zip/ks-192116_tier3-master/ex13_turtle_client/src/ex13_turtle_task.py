#! /usr/bin/env python

import rospy
import actionlib
from ex12_turtle_as.msg import MoveAction, MoveGoal, MoveFeedback, MoveResult


def callback(feedback):
    print('Feedback received:Turtle Moving forward ')
    print(feedback)


rospy.init_node('task13')

client = actionlib.SimpleActionClient('ex12_turtle_as', MoveAction)
client.wait_for_server()

target=MoveGoal()
target.direction="Forward"

client.send_goal(target, feedback_cb = callback)
rospy.sleep(5)
#client.cancel_goal()

client.wait_for_result()
state_result = client.get_state()

print('[Result] State: %d' %state_result)

