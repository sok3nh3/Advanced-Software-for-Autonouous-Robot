#! /usr/bin/env python

import rospy
import math
from goal_publisher.msg import PointArray

def callback(msg):
	j=len(msg.goals)
	for i in range(j):	
		print ("Point {}: x: {}, y: {}, z: {}".format(i,msg.goals[i].x,msg.goals[i].y,msg.goals[i].z))
		i=i+1

rospy.init_node('ex07_subscriber_remap')
rospy.Subscriber('/points',PointArray,callback)
rospy.spin()
