##########################################################################################

     Final Project - Moving Turtle Bot for different goals in Built in Environment using SLAM technique

##########################################################################################

Team Name: Furious_Robot_Developers

Main Project folder: `furiousbotdevelopers` (contains all data needed/used for the challenge).


Project Group Members: 
1. Kiran Siddapura Onkaraiah(@ks-192116)
2. Santosh Basavraj Tavanshi(@st-192119)
3. Sevanth Ganesha Hucchangidurga(@sh-192094 )

Degree: Masters in Electrical Engineering and Embedded systems

Semester: Second

Date:24-07-2020

##########################################################################################

Short Description of the project:

In this project we are running the robot in a built-in environment which has many obstacles and also with other three robot running simultaneously.The  main aim  is to make robot run in this environment and acheive goal point without colliding to obstacles and other robots too.For acheiving this we are using many topics which are subscribed and published.Details of those topics are listed and explained below.

##########################################################################################

Understanding SLAM:

In the Initial steps we went through the tutorial for Navigation from the construct team to understand gmapping and use SLAM by utilizing the topics MOVE_BASE and amcl topic.After this tutorial we understood how to send goals to Move_base topic and the process get localised position using amcl topic. Once these  points are uderstood we started gving simple inputs to MoveBAseACtion x and y to check whether the robot is able to move to target point.After this we tried to sort the goals which we are subscribed from the /goal topic. 

     

###########################################################################################
General description of Topics and Function:

Sr.No| List of Topics       | Subscribed/Published      | Message type    | Message imported from package    | 
:---: | :---         	    | :---                      | :---            | :--- 	                     | 
1    | /goals       	    | Subscribed                | PointArray      | goal-publisher                   |
2    | /amcl                | Subscribed                | PostCovariance  | geometry_msgs	             |
3    |  /move_base/goal     | Published                 | MoveBaseActionGoal       | move-base-msgs          |
4    | /move_base/status    | Subscribed                | GoalstatusArray           | actionlib-msgs         |

1. `/goals` : This topic is subscribed from goal topics to get the goal points and this goal topic is  published from remote controller.

3. `/move_base/goal` : In this topic we are giving goal points for the robot.Move_base package uses this goals points and the build in map and sensor messages to to move and reach the goal points.

2. `/move_base/status` :In this topic we are subscribing the status of Robot goal reaching and if it reached it gives status as 3.which will then be used to increment to next  goal.

4. `/amcl` : amcl is a probablistic localisation system for robot moving in 2D map.It implements adaptive monte carlo localisation approach which takes the particle filter to track the pose of a robot against a known map.It takes in laser based map, laser scans and transform messages and output pose estimates.With this topic we will get continously the localised position of robot. 

5. `/cmd_vel` :This topic we are using to drive the robot by using messages geometry_msgs/Twist. In this project we are using this mainly to rotat the robot in 360degree initiall before starting to move towards goal. This is mainly used to localise all the probablistic  pose of the robot in the forward direction of robot using above amcl topic.

############################################################################################

Algorithm description Implementation steps:


In this section we are explainning how the flow of algorithm works.
1. Before starting of the robot it is rotated 360 degree to localise the robot. After this localisation robot start moving to the goal points which are fed as input after sorting.""

2. First we are subscribing the target goals from /goals topic and making theses goals to one array final_points.After converting to array these points are sent sorting function.

3. In Sorting function initially the array of goal points from above function is converted to a dictionary with key value.Initially we tried Key value with different type like adding x, y and reward points  together and squarring it , Taking reward direclty as a key element of sorting. Since taking reward points  had many  benifits because of which we took that as akey element in sorting teh dictonary. After sorting  these dictionary are fixed with indeces  using OrderedDIC() function.Then we took only values from  these sorted dictionary which was then stored in final_goal_points array.

4. From the above sorted array we are calling reach_goal function in which we are taking every first values of final_goal_points arrays which contains points of x,y and rewards.Then we will give these input to x and y of MoveBaseAction() function which is then pulished for moving the robot.

5. During multiple goal reaching to know when we have to increment to the next goal,we  calculate the distance between robot position and target goal along with the status if the robot is reached the goal. if these conditions are true we  increment the goal to next goal.

6. During the movement of robot from the above input of target pointsthe robot is not able to reach the goal point in specified time then we increment the goal point in order not to waste time reaching a difficult goal or stuck for a long time or avioding other robots in our path, rather incrementing to next goal will help in gaining more rewards.

<img src=" Images/move_base.jpg ">
#############################################################################################
Problems and solutions:


1. Sorting of goal points:
   Since goals are subscribed without sorting the robot may take more time for reaching goals because the goals which are nearer to robot may reach it at the end of goal published. which is like more time consuming and also big travel path for robot to move to all goal points. So to avoid this we have sorted the goal points according the lowest to hghest reward point and then took coordinates of x and y for moving the robot.
	
2. For the status of robot to become as reached goal it will take more time and allignment.
 	To overcome this we have used parameters from /move_base/DWAPlannerROS such as yaw_goal_tolerance and xy_goal_tolerance to get the status for reached goals without much allignment.

 
##############################################################################################

References:

1. Tutorial from the construct team on Gmapping, Move_base
2. http://wiki.ros.org/gmapping accessed on 22 June 2020
3. http://wiki.ros.org/navigation/Tutorials/RobotSetup accessed on 15 June 2020
4. http://library.isr.ist.utl.pt/docs/roswiki/gmapping.html accessed on 1 July 2020
5. https://docs.python.org/3/tutorial/classes.html  accessed on 12 July 2020
6. https://github.com/ros-perception/slam_gmapping/tree/melodic-devel/gmapping accessed on  3 July 2020

###############################################################################################
