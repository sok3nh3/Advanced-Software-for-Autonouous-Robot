import math
from tier2_main_class import LaserModel

testAngle = LaserModel(-math.pi/2, math.pi/2, 2.0,30.0)
testAngle.update_laserdata("laser-testdata/laser-testdata_2")

def func(x):
  return x + 1

def test_works():
  assert func(3) == 4

def test_fails():
  assert func(4) == 5

def test_cal_Angle_Of_Closest_Point():
    assert ((testAngle.calc_angle_of_closest_point() >= testAngle.angle_min) and (testAngle.calc_angle_of_closest_point() <= testAngle.angle_max))==True
