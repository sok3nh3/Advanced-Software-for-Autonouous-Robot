# Welcome to Tier 2!

Welcome back! In this part we will cover some basic python exercises and you will do some basic work with plain sensor data.

If you have never worked with python before we recommend the free parts of the [codecademy python course](https://www.codecademy.com/catalog/language/python).

![](https://fbe-gitlab.hs-weingarten.de/mat-iki/amr-mat/raw/master/.img/tier2.png)
