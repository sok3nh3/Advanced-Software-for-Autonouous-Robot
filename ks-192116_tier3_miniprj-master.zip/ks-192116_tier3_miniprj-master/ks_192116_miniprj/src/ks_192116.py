#!/usr/bin/env python
import rospy
import math
from std_msgs.msg import String
from std_msgs.msg import Int32
from geometry_msgs.msg import Twist          # Import the Twist message from the geometry_msgs
from sensor_msgs.msg import LaserScan       # Import the LaserScan message from the sensor
from gazebo_msgs.msg import ModelStates  #import ModelState message from gazebo_msgs
from geometry_msgs.msg import Pose,Point         # Import the Pose message from the geometry_msgs
from tf.transformations import euler_from_quaternion
from goal_publisher.msg import PointArray
from math import pow, atan2, sqrt
import pdb
import os 

#global varibles declaration
print_x=[0.0]*20
print_y=[0.0]*20
print_z=[0.0]*20
print1_x=[0.0]*20
print1_y=[0.0]*20
i=0
speed=Twist()
x=0
y=0
j=1
front=0
fleft=0
fright=0
theta=0.0
state_ = 0
angle=0.0
error_theta=0
error_position=0
dest_position=Point()
dest_position.x=0	
dest_position.y=0
dest_position.z=0


def model(msg):     # Model state function which is continously providing x,y and theta value of robot while moving
    global x
    global y
    global theta
    x=msg.pose[1].position.x
    y=msg.pose[1].position.y
    rot_q=msg.pose[1].orientation
    (roll,pitch,theta)=euler_from_quaternion([rot_q.x,rot_q.y,rot_q.z,rot_q.w]) #used the formula from the construct


def callback(msg):        #callback function which is continously subscribing the Goals from goal_publisher package
    global print_x,print_y,i,print_z
    print_x=[msg.goals[i].x for i in range(len(msg.goals))]
    print_y=[msg.goals[i].y for i in range(len(msg.goals))]
    print_z=[msg.goals[i].z for i in range(len(msg.goals))]
    #print(print_x)

def change_state(state):  #function which assign the state value and change the function accordingly
    global state_
    state_ = state


def laser(msg):          #getting the laser scan reading and detecting the closest object only front of the robot with a range of 10cm
    global front,fright,fleft
    front = min(min(msg.ranges[0:5]),min(msg.ranges[350:359]),10) 
    fleft =min(min(msg.ranges[18:54]),10)
    left = min(min(msg.ranges[55:90]),10)
    right = min(min(msg.ranges[270:305]),10)
    fright = min(min(msg.ranges[306:341]),10)
    if front > 1 and fleft  > 1 and fright > 1:    
       change_state(0)
    else:        
        change_state(4)
    
    
def tilt_robot():        #When obsacle is detected putting robot in loop to avoid the obstacle in fornt of it
    global front,fleft,fright,speed
    if front < 1:
       move_right()
       move_ahead()

def move_right():         #When obsacle is detected putting robot in loop for moving it in z and x axis till it avoids the obstacle
    for b in range(0,20):
    	turn_right()
        pub.publish(speed)
        rate = rospy.Rate(5)
        rate.sleep()
       
def move_ahead():         #When obsacle is detected robot is moved linearly inx axis after moving robot in right direction 
    for a in range(0,20):
        speed.linear.x = 0.2
        speed.angular.z = 0.0
        rate = rospy.Rate(5)
        pub.publish(speed)
        rate.sleep()

def turn_right():             #When obsacle is detected robot is moved in right direction
    speed.angular.z=-0.3
    speed.linear.x=0


def def_goals():     #goal is being assigned to dest_position.x
    global i,dest_position,print_x,print_y,j   
    dest_position.x=print1_x[0]
    dest_position.y=print1_y[0]
    change_state(1)
    
   

def set_angle(dest_position): #based on goal point robot position in z azis is adjusted 

    global error_theta,angle,angle_precision
    error_theta=math.atan2(dest_position.y - y,dest_position.x - x)
    angle=error_theta-theta
    speed=Twist()

 
    if math.fabs(angle) > 0.1:
          speed.angular.z=0.25 if angle>0 else -0.25
          pub.publish(speed)
    	  
    if math.fabs(angle)<=0.1:
       change_state(2)
    
   

def set_point(dest_position):  # Based on the goal point error_position is calculated and robot is moved accordingly
    global print_x,print_y,pub,error_theta,error_position,angle,theta,front,angle_precision
    error_theta=math.atan2(dest_position.y - y,dest_position.x - x)
    error_position = math.sqrt(pow(dest_position.y - y, 2) + pow(dest_position.x - x, 2))
    angle=error_theta-theta
    speed=Twist()
    
    if abs(error_position) > 0.3:
       speed.linear.x=0.2
       pub.publish(speed)
    else:
       change_state(3)
   
    if abs(angle) > 0.1:
       change_state(1)
    

def stop_it(dest_position):   #   Stopping the robot after reaching the Goal Point
    global speed,i,print_x,print_y,print1_x,print1_y,j
    print("#######################################################################")
    print("For Goal:{}  The target position of robot is x:{} and y :{}".format(j,dest_position.x,dest_position.y))
    print("Goal:{} reached.The position of robot is x:{} and y :{}".format(j,x,y))
    print("#######################################################################")
    speed.linear.x =0
    speed.angular.z =0
    pub.publish(speed)
    rospy.sleep(2)    
    print1_x=print_x[j:]
    print1_y=print_y[j:]
    j=j+1
    change_state(0)
   

def main():
       global print_x,pub,error_position,i,error_theta,print1_x,print1_y
       rospy.init_node('mini')   
       rate = rospy.Rate(10)    
       pub = rospy.Publisher('cmd_vel',Twist, queue_size=10)
       goals_sub = rospy.Subscriber('/goals',PointArray,callback)
       pose_sub = rospy.Subscriber('/gazebo/model_states',ModelStates,model)
       laser_sub = rospy.Subscriber('scan', LaserScan,laser)
       rospy.sleep(2)     
       i=0
       print1_x[0]=print_x[i]
       print1_y[0]=print_y[i]
       while not rospy.is_shutdown():
                 while j < 20 :
   			     if state_==0:
			     	def_goals()
			     elif state_==1:
			     	set_angle(dest_position)
			     elif state_==2:
				  set_point(dest_position)
			     elif state_==3:
                                  stop_it(dest_position)
		 		  rospy.sleep(2)
			     elif state_==4:
			          tilt_robot()
	 		     elif state_==5:
				  turn_left()
			     elif state_==6:
				  turn_right()
if __name__ == '__main__':
  	main()
        rate.sleep()

