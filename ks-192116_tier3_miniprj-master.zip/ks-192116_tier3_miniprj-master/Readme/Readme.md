#####################################################################


     Mini Project -Moving Turtle Boot for different goals in Gazebo

NAME: Kiran Siddapura Onkaraiah

Degree: Masters in Electrical Engineering and Embedded systems

Semester:Second

Date:17-05-2020

#####################################################################

Short Description:

In this Project we are moving the turtle boot from Gazebo simulation to twenty different goals which will be published by another goal_publisher package(a separate folder in the repository) using python libraries and rostopics.

####################################################################

Initial Steps or Beginning with :

Initially I watched many tutorials of turtle boats movement through which I became familiar with python programming and also regarding the turtle boat movement using many topics of Gazebo. To begin with the project have to subscribe the goals from package amr_goals_publisher which was publishing twenty different goals.Next we subscribed the different topics for tracking the position and orientation of turtle boat for moving it .Then with the help of simple logics of using while loop and if loop we achieved the movement of turtle boat to different goals of package amr_goal_publisher.


###################################################################

General description

The main goal of this project was to make turtle boat move around in a 2D plane with specified targets. And if any obstacles is faced then robot shoudl take a turn and start moving to a specific goals which will are being published by a arm_goal_publisher package in parallel.
In this project main topics which we used are
   1. Topic :gazebo/model_states   Action: subscribing --- for keep on getting the values of turtle boat readings to track the position in 2D plane.
   2. Topic :scan      Action: subscribing  ----- for taking 180 degree laser reading to check and avoid the obstacle for a Robot
   3. Topic :goals     Action: subscribing ------ for getting the target goals defined by the project instructor
   4. Topic :cmd_vel   Action: Publishing   ----- for moving the turtle bot in z and x axis 

####################################################################

Algorithm description:

1. In the algorithm first we are subscribing all the above mentioned topics to get the exact position of robot at each seconds.
2. Then  in the first step we are checking the laser reading to detect any obstacle in front of the robot, if it is there then it will go to tilt_robot() function to align the turtle bot till it has no obstacle in front of it . 
3. After avoiding obstacle robot starts calculating the error_theta and error_position in separate function and starts moving accordingly.
4. Once the error_position and error_theta is zero the robot stops and then the first point of array in print_x is deleted and then next target point of print_x is loaded to print1_x .
5. Then same above loop continues till i<19

####################################################################

Implementation:

Here I will explain the two main algorithm which are complex rest of the algorithm are simple and self explanatory

1. set_point()
   In this function we are calculating the error_position using Eucledian distance formula which is sqrt((y2-y1)pow2+(x2-x1)pow2)
   After calculating the error_position the robot will move linearly till error_position >0.4, Once it is less than 0.4 robot will stops
   It also checks if error_theta >0.1 if it is yes then it will go state 1 which is set_angle() described below and keep on adjust his theta position till error_theta<0.1.

2. set_angle()
   In this function program will calculate the error_theta based on the dest_position and then robot will be keep on moving in z axis to align is theta position  near to angle_precision. Once theta is equal to or near to angle_precision robot stops moving in z axis and starts moving in x axis if error_position is still less than >0.4

3. stop_it():
   In this function once the robot moves to dest_position it displays which goal is reached and also delete that goal from the main list of goals. So that once goal is reached robot will assigned with new target for dest_position

####################################################################

Problems and solutions:

I faced three major problem which are 
  1. Printing the goals inside the main function even after it is being continously subscribed in main function :
          Solution which I found was to give same waiting time by rospy.sleep(3) which states to give 3 seconds of waiting time after subscribing through which I was able to take those twenty goals from topic "/goals".
	
  2. Continous movement of turtle boat after acheiving first goal :
         Solution which I found is use of state_ variable through which I can continously switch between the calling functions like def_goals(),set_point(),set_angle()
  3. Not able to increase the index of goals list and the index of destination was alwas 19 :
	 Solution which I found was deleting the goal from the list after reaching the goal through which the turtle boat was moving one goal after the other.
	Further elaborating the solution : print_x was the list to which we were subscribing the twenty goals from package amr_goal_publisher.
once we subscribed and stored the value to print_x always index was this showing at the end of lis which was 19. So what I did was copy the list from print_x to another list print1_x[] and i deleted the j element of print_x[] every time after reaching the goal.
  example: 
	   Before reaching goal 1
           print_x[1.5,2,3,0]
           print1_x=print_x[j:] ### print1_x value is [1.5,2,3,0]
           j=j+1

           After reaching goal 1 
           print_x[1.5,2,3,0]
           print1_x=print_x[j:] ### print1_x value is [2,3,0]
           j=j+1
 
####################################################################
