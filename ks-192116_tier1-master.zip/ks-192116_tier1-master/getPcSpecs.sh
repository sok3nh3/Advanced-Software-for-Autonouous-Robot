#!/bin/bash -e

touch pcspecs.txt

cat /proc/cpuinfo > pcspecs.txt