#!/bin/bash -e

cat pcspecs.txt