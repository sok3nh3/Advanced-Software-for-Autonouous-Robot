#!/bin/bash -e

cat myhistory