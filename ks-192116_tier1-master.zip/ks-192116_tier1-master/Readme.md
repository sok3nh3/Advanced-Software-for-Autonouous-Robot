```
AMR class

This class teaches lot of interesting topic about robotic
 1.ROS
 2.Python
 3.Git
 
ls
ls- la
cd
```


